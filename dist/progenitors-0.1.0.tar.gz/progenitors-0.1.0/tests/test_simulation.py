"""Unit tests for progenitors.simulation module."""
import numpy as np
import pytest


def test_generate_distribution():
    from progenitors.simulation import generate_distribution
    masses, probs = generate_distribution(10.0, 15.0)
    assert len(masses) == int((15 - 10) / 0.1)
    assert len(probs) == len(masses)
    assert np.all(probs > 0)
    assert masses[0] == 10.0
    assert masses[-1] == 15.0


def test_generate_sample():
    from progenitors.simulation import generate_sample
    masses = np.array([1.0, 2.0, 3.0])
    probs = np.array([0.2, 0.5, 0.3])
    out = generate_sample(masses, probs, 10)
    assert len(out) == 10
    flat = np.array(out).flatten()
    assert len(flat) == 10
    assert np.all(np.isin(flat, masses))


def test_calculate_chi2():
    from progenitors.simulation import calculate_chi2
    inp = np.array([10.0, 12.0, 14.0])
    sim = np.array([10.1, 11.9, 14.2])
    lims = np.array([1.0, 1.0, 1.0])
    chi2 = calculate_chi2(inp, sim, lims)
    assert chi2 >= 0
    assert np.isfinite(chi2)
    # Same inputs give zero
    z = calculate_chi2(inp, inp, lims)
    assert z == 0.0
