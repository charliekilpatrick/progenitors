"""Tests for progenitors package public API and pipeline/simulation entry points."""
import pytest


def test_package_import():
    import progenitors
    assert hasattr(progenitors, "params")
    assert hasattr(progenitors, "parse_arguments")
    assert hasattr(progenitors, "message")


def test_params_from_init():
    from progenitors import params
    assert "SHEET" in params or "metadata" in params
    assert "target" in params


def test_pipeline_import():
    from progenitors.pipeline import main, do_trim_metadata
    assert callable(main)
    assert callable(do_trim_metadata)


def test_main_entry_point():
    from progenitors.__main__ import main
    assert callable(main)


def test_simulation_run_import():
    """progenitors.simulation.run exposes pipeline main."""
    from progenitors.simulation import run
    assert hasattr(run, "main")
    assert callable(run.main)
    # main() is only run when script is executed (if __name__ == "__main__")
