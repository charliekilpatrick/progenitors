"""
IMF-style mass fit: M_hi_lo_fit from IDL.
Given cumulative fraction X in [0,1], returns mass F from power-law CDF
between M_lo (A[0]) and M_hi (A[1]) with GAMMA = -1.35.
"""
import numpy as np
from scipy.optimize import curve_fit

GAMMA = -1.35


def m_hi_lo_fit(x, m_lo, m_hi):
    """Power-law (IMF) cumulative distribution: mass at cumulative fraction x."""
    x = np.asarray(x, dtype=float)
    a0, a1 = float(m_lo), float(m_hi)
    a0g = a0 ** GAMMA
    a1g = a1 ** GAMMA
    norm = 1.0 / (a1g - a0g)
    inner = np.clip(x / norm + a0g, 1e-300, np.inf)
    expo = (1.0 / GAMMA) * np.log10(inner)
    return 10.0 ** expo


def fit_m_hi_lo(nn_tofit, masses_tofit, p0=(8.0, 20.0)):
    """Fit M_lo, M_hi to sorted mass vs cumulative fraction using curve_fit."""
    nn_tofit = np.asarray(nn_tofit, dtype=float)
    masses_tofit = np.asarray(masses_tofit, dtype=float)
    popt, pcov = curve_fit(
        lambda x, m_lo, m_hi: m_hi_lo_fit(x, m_lo, m_hi),
        nn_tofit,
        masses_tofit,
        p0=p0,
        bounds=([0.1, 1.0], [200, 200]),
    )
    return (float(popt[0]), float(popt[1])), popt, pcov
