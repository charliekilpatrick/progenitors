"""Mass-distribution and χ² simulation utilities for progenitor analysis."""
from .core import generate_distribution, generate_sample, calculate_chi2, main as simulation_main

__all__ = ["generate_distribution", "generate_sample", "calculate_chi2", "simulation_main"]
