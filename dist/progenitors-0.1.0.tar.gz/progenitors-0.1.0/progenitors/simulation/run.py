"""Alternate pipeline entry: run progenitor pipeline (Sheets + metadata) with minimal options."""
import copy
import sys
from astropy.table import unique
from progenitors import util
from progenitors.sheets import sheetproc


def main(redo=False, download_yse=True, update_classification=False):
    sndata = sheetproc.download_progenitor_data(util.params["SHEET"])
    sndata = sheetproc.load_metadata_from_file(sndata, util.params["metadata"])

    if download_yse:
        sndata = util.add_yse_targets(sndata)

    all_keys = list(sndata.keys())
    for type_key in all_keys:
        for row in sndata[type_key]:
            util.get_spectra(row, sndata[type_key])

        for dattype in ["ned", "distance", "tns", "osc", "yse", "ads", "hst"]:
            update = util.add_metadata(sndata[type_key], dattype, redo=redo)
            if vars(update) != vars(sndata[type_key]):
                sndata[type_key] = copy.copy(update)
                sheetproc.save_metadata_to_file(
                    {type_key: sndata[type_key]}, util.params["metadata"]
                )

        for coltype in [
            "OSC", "TNS", "YSEPZ", "Host", "Discovery Date",
            "Classification", "Distance", "Redshift", "NED", "HST",
            "Distance Method", "Ref. (Distance)",
            "Ref. (Classification)", "Ref. (Discovery)",
        ]:
            print("Running", coltype, "for", type_key)
            sndata[type_key] = util.add_data(sndata[type_key], coltype)

        if len(sndata[type_key]) > 1:
            sndata[type_key] = unique(sndata[type_key], keys="Name")

        if "Discovery Date" in sndata[type_key].keys():
            sndata[type_key].sort("Discovery Date")

        sndata[type_key].meta["mask"] = util.get_classification_mask(sndata[type_key])

        sheetproc.upload_progenitor_data(util.params["SHEET"], sndata, mask=True)
        sheetproc.save_metadata_to_file(sndata, util.params["metadata"])

    if update_classification:
        new_sndata = {}
        for key in all_keys:
            print("Updating classifications", key)
            new_sndata[key] = util.gather_type(sndata, key)
            print("Objects in sheet", key, len(new_sndata[key]))
            if "Discovery Date" in new_sndata[key].keys():
                new_sndata[key].sort("Discovery Date")
            new_sndata[key].meta["mask"] = util.get_classification_mask(new_sndata[key])
        sheetproc.upload_progenitor_data(util.params["SHEET"], new_sndata, mask=True)
        sheetproc.save_metadata_to_file(new_sndata, util.params["metadata"])


if __name__ == "__main__":
    main(redo=False, update_classification=True)
