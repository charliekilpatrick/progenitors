# Progenitors

Methods for downloading, organizing, and analyzing data used to identify and classify progenitor systems of explosive transients (e.g., supernovae). The codebase supports a Google Sheets–driven pipeline for progenitor targets, SED fitting from photometry, and simulation utilities for mass distributions.

---

## What This Repository Can Do

- **Progenitor pipeline** — Sync a Google Sheet of transient targets with metadata from external services (TNS, YSE-PZ, NED, NASA ADS, Open Supernova Catalog, MAST for HST/JWST). Enrich tables with host galaxy info, distances, redshifts, discovery/classification references, and pre-/post-explosion imaging. Optionally reclassify objects across sheets and send email alerts for new candidates.
- **SED fitting** — Fit photometry to stellar SED models (blackbody, Pickles atlas, MIST/BPASS tracks, red supergiant models with dust) using MCMC (emcee) or nested sampling (dynesty). Compare to theoretical tracks, produce corner plots and SED/HR diagrams. Used for progenitor characterization from pre-explosion or late-time photometry.
- **Simulation** — Utilities for mass-distribution and χ² comparisons (e.g., for progenitor mass functions).
- **Extinction** — Supporting data and notebooks for extinction work (see `extinction/`).

All authentication (API keys, tokens, passwords) is read from **environment variables**; the pipeline validates required variables at startup and exits with a clear message if any are missing.

---

## Installation

### Requirements

- Python 3.8 or later  
- See `pyproject.toml` and `environment.yml` for dependency lists.

### Option 1: Pip (from repository root)

```bash
git clone <repository-url>
cd progenitors
pip install -e .
```

To install with development dependencies (pytest, pytest-cov):

```bash
pip install -e ".[dev]"
```

### Option 2: Conda

Create and activate the environment:

```bash
conda env create -f environment.yml
conda activate progenitors
pip install -e .
```

To update the environment later:

```bash
conda env update -f environment.yml --prune
```

### Quick check

From the repo root:

```bash
progenitors --help
pytest tests/ -v
```

### Documentation (Sphinx)

From the repo root, with dev dependencies installed:

```bash
pip install -e ".[dev]"
sphinx-build -b html docs docs/_build
open docs/_build/index.html   # or open docs/_build/html/index.html on Windows
```

See `docs/README.md` for details. The docs include API reference for the SED module (numpy-style docstrings).

---

## Configuration: Environment Variables

All usernames, passwords, API keys, and tokens are read from **environment variables** only. The pipeline checks required variables at startup and exits with a clear message if any are missing.

| Purpose | Variable(s) | Required when |
|--------|-------------|----------------|
| Google Sheet | `PROGENITORS_SHEET` | Always for pipeline |
| Google OAuth | `credentials.json` at repo root (or `PROGENITORS_CREDENTIALS_PATH`) | Using Sheets |
| YSE-PZ | `YSE_USER`, `YSE_PASSWORD` | Pipeline (adds YSE targets) |
| TNS | `TNS_API_KEY`, `TNS_BOT_NAME`, `TNS_BOT_ID` | Using TNS metadata |
| NASA ADS | `ADS_AUTHCODE` | Using ADS metadata |
| Email alerts | `GMAIL_LOGIN`, `GMAIL_PASSWORD`, `MY_EMAIL` | Using `--alert` |

**Example setup** — Copy the example script, fill in your values, and source it before running (from repo root):

```bash
cp progenitors/scripts/set_env_example.sh my_env.sh
# Edit my_env.sh with your credentials
source my_env.sh
progenitors
```

Or print export commands and eval them:

```bash
eval $(python -m progenitors.scripts.set_env_example)
progenitors
```

See `progenitors.env_config` for the full list and validation logic.

### Where settings live

Hard-coded pipeline and module settings (no API keys or passwords) are in **`progenitors/settings/`** so they are easy to find and change:

| File | Used by | Contents |
|------|---------|----------|
| `settings/pipeline.py` | pipeline, __main__, options | Default metadata types, default features, trim keep_keys, default YSE SQL query |
| `settings/env_config.py` | env_config | Env var names per feature, descriptions for error messages |
| `settings/sheets.py` | sheets.sheetproc | Sheet column names, Google OAuth scopes |
| `settings/util.py` | util | Distance-method hierarchy, email alert template (from/subject/SMTP) |
| `settings/sed_analysis.py` | sed.analysis | SED model fit parameter names by model type |

Each consuming module’s docstring states which settings file it uses.

---

## Usage and Examples

### Running the progenitor pipeline

After setting environment variables (and placing `credentials.json` for Google Sheets at repo root):

```bash
# Full run (Sheets + metadata + optional alert)
progenitors

# Re-run metadata for all objects
progenitors --redo

# Only update specific metadata types
progenitors --metadata osc,jwst,ned,distance,tns,yse,ads,hst

# Re-do metadata for specific objects only
progenitors --redo-obj 2020fqv,2021yja

# Update classification and send email for new YSE targets
progenitors --update-classification --alert

# Trim metadata keys that no longer match the table
progenitors --trim-metadata
```

As a Python module:

```bash
python -m progenitors
```

### Using the package from Python

```python
from progenitors import params, parse_arguments
from progenitors.util import get_coord, get_classification_mask, is_number
from progenitors.sheets import download_progenitor_data, load_metadata_from_file
from progenitors.env_config import validate_env, get_env

# Validate required env vars for a subset of features
validate_env(["sheets", "yse"], credentials_path="/path/to/credentials.json")

# Download sheet data (requires PROGENITORS_SHEET and credentials)
sndata = download_progenitor_data(params["SHEET"])
sndata = load_metadata_from_file(sndata, params["metadata"])
```

### SED fitting (sed/)

The `sed/` package fits photometry to stellar SED models (blackbody, Pickles, RSG, MIST, BPASS, etc.) and uses emcee for MCMC. Run from the `sed/` directory or adjust paths; see `sed/analysis.py` and `sed/plotting.py` for entry points and options. Requires additional data (bandpasses, dust, model grids) and optional dependencies (synphot, emcee; stsynphot for HST/JWST filters).

### Simulation (progenitors.simulation)

```python
from progenitors.simulation import generate_distribution, generate_sample, calculate_chi2
import numpy as np

masses, probs = generate_distribution(10.0, 15.0)
samples = generate_sample(masses, probs, 100)
chi2 = calculate_chi2(observed_masses, sim_masses, limits)
```

### Examples (testing each module)

The `examples/` directory contains runnable scripts that exercise each major module without live credentials or network (except where noted). Useful for smoke-testing after install or when changing code.

```bash
# From repository root (with package installed)
python examples/example_util.py
python examples/example_options.py
python examples/example_sed_constants.py
# ... see examples/README.md for the full list

# Run all examples
for f in examples/example_*.py; do python "$f" || exit 1; done
```

See **`examples/README.md`** for a table of scripts and the modules they cover.

---

## Tests

Tests use **pytest**. Run them from the repository root (with the package installed, e.g. in a venv or conda env).

### Run all tests

```bash
pytest
```

### Run with verbose output

```bash
pytest -v
```

### Run with coverage

```bash
pytest --cov=progenitors --cov-report=term-missing
```

### Run a subset of tests

```bash
pytest tests/test_util.py tests/test_env_config.py -v
pytest tests/ -k "sheetproc or options" -v
```

Unit tests cover the `progenitors` package (util, options, pipeline, sheets, env_config, simulation, scripts), `progenitors.sed` (constants, utilities, analysis basics), `progenitors.extinction` and `progenitors.davies18` (package presence and data). Code that requires network access or live credentials (Google Sheets, MAST, TNS, etc.) is not exercised by default.

---

## Repository Layout

| Path | Description |
|------|-------------|
| `progenitors/` | Main Python package: pipeline, util, options, env_config, sheets (Google Sheets I/O) |
| `progenitors/settings/` | **Pipeline settings** (no secrets): default metadata list, sheet columns, env var names, distance-method hierarchy, email template, SED model fit params. See each module’s docstring for which settings file it uses. |
| `progenitors/sed/` | SED fitting: analysis, plotting, dust, constants, utilities; data and plotting scripts |
| `progenitors/extinction/` | Extinction-related data and notebooks |
| `progenitors/davies18/` | Davies et al. progenitor data and IDL scripts (.pro, .csv) |
| `progenitors/simulation/` | Mass-distribution and χ² utilities; alternate pipeline entry in `run.py` |
| `progenitors/scripts/` | `set_env_example.sh`, `set_env_example.py` (env var examples); `sed/` helpers (create_example_sed, get_rv, plotting_bkp) |
| `progenitors/sed/scripts/` | Shell scripts for SED model runs |
| `examples/` | Runnable scripts to test each module; see `examples/README.md` |
| `tests/` | Pytest suite; `tests/sed/` for SED-related tests; tests for extinction and davies18 |

---

## Submitting Issues

If you run into a bug or have a feature request:

1. **Check existing issues** — Search the repository issues to see if the problem or request is already reported.
2. **Open a new issue** — Include:
   - A short, clear title
   - Steps to reproduce (for bugs) or a concise description (for feature requests)
   - Your environment: OS, Python version, how you installed (pip vs conda), and whether you use the example env script
   - Any relevant error messages or logs (redact credentials and API keys)
3. **Be specific** — For bugs, note the exact command or code path that fails. For feature requests, describe the use case and desired behavior.

---

## Contact

For questions, problems, or collaboration related to this repository:

**Charlie Kilpatrick**  
ckilpatrick@northwestern.edu

Include a brief description of what you’re trying to do and what went wrong (or what you’d like to add), and your environment details if relevant.
